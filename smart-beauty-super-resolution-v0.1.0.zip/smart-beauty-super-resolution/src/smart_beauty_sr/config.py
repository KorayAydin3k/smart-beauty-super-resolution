from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from smart_beauty_sr.contracts import (
    ConfigurationError,
    EligibilityConfig,
    ModelConfig,
    SRProfile,
    SourceLimits,
)

_ROOT_FIELDS = {
    "schema_version",
    "profile_id",
    "profile_version",
    "model",
    "eligibility",
    "source_limits",
    "output_format",
}
_MODEL_FIELDS = {
    "backend",
    "scale",
    "model_id",
    "revision",
    "device",
    "deterministic",
    "use_safetensors",
}
_ELIGIBILITY_FIELDS = {
    "enhance_if_short_side_below",
    "min_focus_score",
    "passthrough_if_not_needed",
}
_LIMIT_FIELDS = {"max_width", "max_height", "max_pixels", "max_output_pixels"}


def _mapping(name: str, value: object) -> dict[str, Any]:
    if not isinstance(value, dict) or any(not isinstance(k, str) for k in value):
        raise ConfigurationError(f"{name} must be a string-keyed mapping")
    return value


def _exact_fields(name: str, payload: dict[str, Any], expected: set[str]) -> None:
    missing = sorted(expected - payload.keys())
    unknown = sorted(payload.keys() - expected)
    if missing:
        raise ConfigurationError(f"{name} is missing fields: {', '.join(missing)}")
    if unknown:
        raise ConfigurationError(f"{name} has unknown fields: {', '.join(unknown)}")


def profile_from_mapping(value: object) -> SRProfile:
    root = _mapping("profile", value)
    _exact_fields("profile", root, _ROOT_FIELDS)
    model_payload = _mapping("model", root["model"])
    eligibility_payload = _mapping("eligibility", root["eligibility"])
    limits_payload = _mapping("source_limits", root["source_limits"])
    _exact_fields("model", model_payload, _MODEL_FIELDS)
    _exact_fields("eligibility", eligibility_payload, _ELIGIBILITY_FIELDS)
    _exact_fields("source_limits", limits_payload, _LIMIT_FIELDS)

    return SRProfile(
        schema_version=str(root["schema_version"]),
        profile_id=str(root["profile_id"]),
        profile_version=str(root["profile_version"]),
        model=ModelConfig(**model_payload),
        eligibility=EligibilityConfig(**eligibility_payload),
        source_limits=SourceLimits(**limits_payload),
        output_format=str(root["output_format"]),
    )


def load_profile(path: Path) -> SRProfile:
    try:
        payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise ConfigurationError(f"unable to read profile: {path}") from exc
    except yaml.YAMLError as exc:
        raise ConfigurationError(f"invalid YAML profile: {path}") from exc
    return profile_from_mapping(payload)
