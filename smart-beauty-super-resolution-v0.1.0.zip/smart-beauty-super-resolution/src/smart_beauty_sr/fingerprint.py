from __future__ import annotations

import hashlib
import json
from dataclasses import asdict

from smart_beauty_sr.contracts import SRProfile


def profile_sha256(profile: SRProfile) -> str:
    payload = json.dumps(asdict(profile), sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()
