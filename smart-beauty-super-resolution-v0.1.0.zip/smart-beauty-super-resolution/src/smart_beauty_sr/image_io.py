from __future__ import annotations

import hashlib
import os
import tempfile
from pathlib import Path

import numpy as np
from PIL import Image, ImageOps


def decode_rgb(path: Path) -> np.ndarray:
    with Image.open(path) as source:
        oriented = ImageOps.exif_transpose(source)
        rgb = oriented.convert("RGB")
        return np.ascontiguousarray(np.asarray(rgb, dtype=np.uint8))


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_pixels(image: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(image).tobytes()).hexdigest()


def atomic_write_png(path: Path, image: np.ndarray) -> None:
    if image.ndim != 3 or image.shape[2] != 3 or image.dtype != np.uint8:
        raise ValueError("output image must be RGB uint8")
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.stem}.", suffix=".tmp.png", dir=path.parent)
    os.close(fd)
    temp_path = Path(temp_name)
    try:
        Image.fromarray(image, mode="RGB").save(temp_path, format="PNG", optimize=False)
        os.replace(temp_path, path)
    finally:
        temp_path.unlink(missing_ok=True)
