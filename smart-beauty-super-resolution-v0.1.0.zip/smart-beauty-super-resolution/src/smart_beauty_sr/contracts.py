from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import StrEnum
from pathlib import Path
from typing import Any


class SmartBeautySRError(Exception):
    """Base error for expected super-resolution failures."""


class ConfigurationError(SmartBeautySRError):
    """Raised when a profile or runtime configuration is invalid."""


class ImageLimitError(SmartBeautySRError):
    """Raised when an image exceeds configured safety limits."""


class ImageQualityError(SmartBeautySRError):
    """Raised when an image is too degraded for analysis-safe SR."""


class OutputCollisionError(SmartBeautySRError):
    """Raised when multiple sources map to the same output path."""


class BackendUnavailableError(SmartBeautySRError):
    """Raised when an optional model backend cannot be loaded."""


class BackendInferenceError(SmartBeautySRError):
    """Raised when a configured model backend fails during loading or inference."""


class Decision(StrEnum):
    ENHANCE = "enhance"
    PASSTHROUGH = "passthrough"
    REJECT = "reject"


class ProcessingStatus(StrEnum):
    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass(frozen=True, slots=True)
class SourceLimits:
    max_width: int = 4096
    max_height: int = 4096
    max_pixels: int = 16_777_216
    max_output_pixels: int = 67_108_864

    def __post_init__(self) -> None:
        for name, value in asdict(self).items():
            if type(value) is not int or value <= 0:
                raise ConfigurationError(f"{name} must be a positive integer")


@dataclass(frozen=True, slots=True)
class EligibilityConfig:
    enhance_if_short_side_below: int = 1024
    min_focus_score: float = 12.0
    passthrough_if_not_needed: bool = True

    def __post_init__(self) -> None:
        if (
            type(self.enhance_if_short_side_below) is not int
            or self.enhance_if_short_side_below <= 0
        ):
            raise ConfigurationError("enhance_if_short_side_below must be a positive integer")
        if isinstance(self.min_focus_score, bool) or float(self.min_focus_score) < 0:
            raise ConfigurationError("min_focus_score must be a non-negative number")


@dataclass(frozen=True, slots=True)
class ModelConfig:
    backend: str
    scale: int
    model_id: str | None = None
    revision: str | None = None
    device: str = "auto"
    deterministic: bool = True
    use_safetensors: bool = True

    def __post_init__(self) -> None:
        if self.backend not in {"bicubic", "hf_swin2sr"}:
            raise ConfigurationError("backend must be 'bicubic' or 'hf_swin2sr'")
        if self.scale not in {2, 4}:
            raise ConfigurationError("scale must be 2 or 4")
        if self.backend == "hf_swin2sr" and not self.model_id:
            raise ConfigurationError("model_id is required for hf_swin2sr")
        if self.backend == "hf_swin2sr":
            if self.revision is None or len(self.revision) != 40:
                raise ConfigurationError("hf_swin2sr requires a full 40-character revision")
            if any(character not in "0123456789abcdef" for character in self.revision):
                raise ConfigurationError("revision must be lowercase hexadecimal")
        if self.device not in {"auto", "cpu", "cuda", "mps"}:
            raise ConfigurationError("device must be auto, cpu, cuda, or mps")


@dataclass(frozen=True, slots=True)
class SRProfile:
    schema_version: str
    profile_id: str
    profile_version: str
    model: ModelConfig
    eligibility: EligibilityConfig
    source_limits: SourceLimits
    output_format: str = "png"

    def __post_init__(self) -> None:
        if self.schema_version != "1.0":
            raise ConfigurationError("unsupported profile schema_version")
        if not self.profile_id.strip():
            raise ConfigurationError("profile_id must be non-empty")
        if self.output_format.lower() != "png":
            raise ConfigurationError("only deterministic RGB PNG output is supported")


@dataclass(frozen=True, slots=True)
class EligibilityMetrics:
    width: int
    height: int
    pixels: int
    short_side: int
    focus_score: float


@dataclass(frozen=True, slots=True)
class EligibilityResult:
    decision: Decision
    reason: str
    metrics: EligibilityMetrics


@dataclass(frozen=True, slots=True)
class ProcessRecord:
    source_path: str
    output_path: str | None
    status: ProcessingStatus
    decision: Decision | None
    reason: str | None
    source_sha256: str | None
    source_pixel_sha256: str | None
    output_sha256: str | None
    output_pixel_sha256: str | None
    profile_sha256: str
    source_width: int | None
    source_height: int | None
    output_width: int | None
    output_height: int | None
    focus_score: float | None
    backend: str
    model_id: str | None
    model_revision: str | None
    device: str
    elapsed_ms: float
    error_type: str | None = None
    error_message: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["status"] = self.status.value
        payload["decision"] = self.decision.value if self.decision else None
        return payload


@dataclass(frozen=True, slots=True)
class BatchResult:
    records: tuple[ProcessRecord, ...]
    manifest_path: Path
    summary_path: Path

    @property
    def succeeded(self) -> int:
        return sum(record.status is ProcessingStatus.SUCCESS for record in self.records)

    @property
    def failed(self) -> int:
        return sum(record.status is ProcessingStatus.FAILED for record in self.records)

    @property
    def skipped(self) -> int:
        return sum(record.status is ProcessingStatus.SKIPPED for record in self.records)
