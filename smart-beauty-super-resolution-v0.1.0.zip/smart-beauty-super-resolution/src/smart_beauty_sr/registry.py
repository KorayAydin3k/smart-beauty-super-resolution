from __future__ import annotations

from smart_beauty_sr.backends.base import SuperResolutionBackend
from smart_beauty_sr.backends.bicubic import BicubicBackend
from smart_beauty_sr.backends.hf_swin2sr import HFSwin2SRBackend
from smart_beauty_sr.contracts import ModelConfig


def create_backend(config: ModelConfig) -> SuperResolutionBackend:
    if config.backend == "bicubic":
        return BicubicBackend(config.scale)
    return HFSwin2SRBackend(config)
