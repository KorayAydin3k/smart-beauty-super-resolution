from __future__ import annotations

import cv2
import numpy as np

from smart_beauty_sr.contracts import (
    Decision,
    EligibilityMetrics,
    EligibilityResult,
    SRProfile,
)


def focus_score(image: np.ndarray) -> float:
    """Return deterministic Laplacian variance as a focus proxy."""
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    return float(cv2.Laplacian(gray, cv2.CV_64F).var())


def evaluate_eligibility(image: np.ndarray, profile: SRProfile) -> EligibilityResult:
    if image.ndim != 3 or image.shape[2] != 3 or image.dtype != np.uint8:
        raise ValueError("image must be RGB uint8")

    height, width = image.shape[:2]
    pixels = width * height
    score = focus_score(image)
    metrics = EligibilityMetrics(
        width=width,
        height=height,
        pixels=pixels,
        short_side=min(width, height),
        focus_score=score,
    )
    limits = profile.source_limits
    if width > limits.max_width or height > limits.max_height or pixels > limits.max_pixels:
        return EligibilityResult(Decision.REJECT, "source image exceeds configured limits", metrics)

    output_pixels = pixels * profile.model.scale * profile.model.scale
    if output_pixels > limits.max_output_pixels:
        return EligibilityResult(
            Decision.REJECT,
            "projected output exceeds max_output_pixels",
            metrics,
        )

    if score < profile.eligibility.min_focus_score:
        return EligibilityResult(
            Decision.REJECT,
            "image is too blurred for analysis-safe SR",
            metrics,
        )

    if metrics.short_side >= profile.eligibility.enhance_if_short_side_below:
        decision = (
            Decision.PASSTHROUGH
            if profile.eligibility.passthrough_if_not_needed
            else Decision.REJECT
        )
        return EligibilityResult(decision, "super-resolution is not required", metrics)

    return EligibilityResult(Decision.ENHANCE, "image is eligible for super-resolution", metrics)
