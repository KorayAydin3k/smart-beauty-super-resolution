from smart_beauty_sr.cli import app

app()
