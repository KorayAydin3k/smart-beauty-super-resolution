from __future__ import annotations

import json
from pathlib import Path

from smart_beauty_sr.backends.base import SuperResolutionBackend
from smart_beauty_sr.contracts import BatchResult, OutputCollisionError, ProcessingStatus, SRProfile
from smart_beauty_sr.fingerprint import profile_sha256
from smart_beauty_sr.pipeline import process_image

_SUPPORTED = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}


def discover_images(input_dir: Path) -> tuple[Path, ...]:
    return tuple(
        sorted(
            (
                path
                for path in input_dir.rglob("*")
                if path.is_file() and path.suffix.lower() in _SUPPORTED
            ),
            key=lambda path: path.relative_to(input_dir).as_posix().casefold(),
        )
    )


def output_path_for(source: Path, input_dir: Path, output_dir: Path) -> Path:
    return (output_dir / source.relative_to(input_dir)).with_suffix(".png")


def _preflight(sources: tuple[Path, ...], input_dir: Path, output_dir: Path) -> None:
    seen: dict[str, Path] = {}
    for source in sources:
        output = output_path_for(source, input_dir, output_dir)
        key = output.as_posix().casefold()
        if key in seen:
            raise OutputCollisionError(f"{seen[key]} and {source} map to {output}")
        seen[key] = source


def _write_text_atomic(path: Path, text: str) -> None:
    temp = path.with_name(f".{path.name}.tmp")
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        temp.write_text(text, encoding="utf-8")
        temp.replace(path)
    finally:
        temp.unlink(missing_ok=True)


def process_batch(
    input_dir: Path,
    output_dir: Path,
    profile: SRProfile,
    backend: SuperResolutionBackend,
    *,
    fail_fast: bool = False,
    overwrite: bool = False,
) -> BatchResult:
    sources = discover_images(input_dir)
    _preflight(sources, input_dir, output_dir)
    records = []
    for source in sources:
        record = process_image(
            source,
            output_path_for(source, input_dir, output_dir),
            profile,
            backend,
            overwrite=overwrite,
        )
        records.append(record)
        if fail_fast and record.status is ProcessingStatus.FAILED:
            break

    run_dir = output_dir / "_runs"
    manifest_path = run_dir / "manifest.jsonl"
    summary_path = run_dir / "run_summary.json"
    manifest = "".join(json.dumps(record.to_dict(), sort_keys=True) + "\n" for record in records)
    _write_text_atomic(manifest_path, manifest)
    summary = {
        "schema_version": "1.0",
        "profile_id": profile.profile_id,
        "profile_version": profile.profile_version,
        "profile_sha256": profile_sha256(profile),
        "backend": backend.name,
        "model_id": profile.model.model_id,
        "model_revision": profile.model.revision,
        "device": backend.device,
        "discovered": len(sources),
        "processed": len(records),
        "succeeded": sum(record.status is ProcessingStatus.SUCCESS for record in records),
        "failed": sum(record.status is ProcessingStatus.FAILED for record in records),
        "skipped": sum(record.status is ProcessingStatus.SKIPPED for record in records),
    }
    _write_text_atomic(summary_path, json.dumps(summary, indent=2, sort_keys=True) + "\n")
    return BatchResult(tuple(records), manifest_path, summary_path)
