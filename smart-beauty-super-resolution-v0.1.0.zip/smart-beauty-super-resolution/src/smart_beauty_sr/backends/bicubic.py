from __future__ import annotations

import numpy as np
from PIL import Image


class BicubicBackend:
    """Deterministic non-neural baseline used for CI and comparisons."""

    name = "bicubic"
    device = "cpu"

    def __init__(self, scale: int) -> None:
        self.scale = scale

    def enhance(self, image: np.ndarray) -> np.ndarray:
        height, width = image.shape[:2]
        output = Image.fromarray(image, mode="RGB").resize(
            (width * self.scale, height * self.scale),
            resample=Image.Resampling.BICUBIC,
        )
        return np.ascontiguousarray(np.asarray(output, dtype=np.uint8))
