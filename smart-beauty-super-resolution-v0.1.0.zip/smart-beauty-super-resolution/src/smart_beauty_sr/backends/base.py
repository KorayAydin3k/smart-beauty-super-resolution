from __future__ import annotations

from typing import Protocol

import numpy as np


class SuperResolutionBackend(Protocol):
    name: str
    scale: int
    device: str

    def enhance(self, image: np.ndarray) -> np.ndarray:
        """Enhance one RGB uint8 image and return RGB uint8 output."""
        ...
