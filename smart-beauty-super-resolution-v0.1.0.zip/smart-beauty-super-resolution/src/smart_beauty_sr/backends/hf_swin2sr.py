from __future__ import annotations

from typing import Any

import numpy as np
from PIL import Image

from smart_beauty_sr.contracts import (
    BackendInferenceError,
    BackendUnavailableError,
    ModelConfig,
)


def reconstruction_to_rgb_uint8(
    array: np.ndarray,
    expected_height: int,
    expected_width: int,
) -> np.ndarray:
    """Convert a CHW float reconstruction and remove processor padding."""
    if array.ndim != 3 or array.shape[0] != 3:
        raise BackendInferenceError("model reconstruction must have CHW RGB shape")
    image = np.transpose(array, (1, 2, 0))
    if image.shape[0] < expected_height or image.shape[1] < expected_width:
        raise BackendInferenceError(
            "model reconstruction is smaller than the expected scaled image"
        )
    image = image[:expected_height, :expected_width]
    return np.ascontiguousarray(np.rint(np.clip(image, 0, 1) * 255.0).astype(np.uint8))


class HFSwin2SRBackend:
    """Lazy Hugging Face Swin2SR backend for analysis-safe enhancement."""

    name = "hf_swin2sr"

    def __init__(self, config: ModelConfig) -> None:
        self.scale = config.scale
        self._config = config
        self._processor: Any | None = None
        self._model: Any | None = None
        self._torch: Any | None = None
        self.device = config.device

    def _load(self) -> None:
        if self._model is not None:
            return
        try:
            import torch
            from transformers import Swin2SRForImageSuperResolution, Swin2SRImageProcessor
        except ImportError as exc:
            raise BackendUnavailableError(
                "install the model extra: pip install 'smart-beauty-super-resolution[model]'"
            ) from exc

        device = self._config.device
        if device == "auto":
            if torch.cuda.is_available():
                device = "cuda"
            elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                device = "mps"
            else:
                device = "cpu"

        try:
            if self._config.deterministic:
                torch.manual_seed(0)
                if torch.cuda.is_available():
                    torch.cuda.manual_seed_all(0)
                torch.use_deterministic_algorithms(True)
                if hasattr(torch.backends, "cudnn"):
                    torch.backends.cudnn.benchmark = False
                    torch.backends.cudnn.deterministic = True

            model_id = self._config.model_id
            assert model_id is not None
            revision = self._config.revision
            self._processor = Swin2SRImageProcessor.from_pretrained(
                model_id,
                revision=revision,
            )
            self._model = Swin2SRForImageSuperResolution.from_pretrained(
                model_id,
                revision=revision,
                use_safetensors=self._config.use_safetensors,
            ).to(device)
            self._model.eval()
            self._torch = torch
            self.device = device
        except Exception as exc:
            raise BackendInferenceError(f"unable to load Swin2SR backend: {exc}") from exc

    def enhance(self, image: np.ndarray) -> np.ndarray:
        self._load()
        assert self._processor is not None
        assert self._model is not None
        assert self._torch is not None

        try:
            pil_image = Image.fromarray(image, mode="RGB")
            inputs = self._processor(images=pil_image, return_tensors="pt")
            inputs = {key: value.to(self.device) for key, value in inputs.items()}
            with self._torch.inference_mode():
                outputs = self._model(**inputs)
            reconstruction = outputs.reconstruction
            array = reconstruction.squeeze(0).detach().float().cpu().numpy()
            return reconstruction_to_rgb_uint8(
                array,
                expected_height=image.shape[0] * self.scale,
                expected_width=image.shape[1] * self.scale,
            )
        except Exception as exc:
            raise BackendInferenceError(f"Swin2SR inference failed: {exc}") from exc
