from __future__ import annotations

import math

import cv2
import numpy as np


def psnr(reference: np.ndarray, candidate: np.ndarray) -> float:
    if reference.shape != candidate.shape:
        raise ValueError("images must have identical shapes")
    mse = float(np.mean((reference.astype(np.float64) - candidate.astype(np.float64)) ** 2))
    return math.inf if mse == 0 else 20.0 * math.log10(255.0 / math.sqrt(mse))


def ssim(reference: np.ndarray, candidate: np.ndarray) -> float:
    """Return mean channel SSIM using the standard Gaussian-window formulation."""
    if reference.shape != candidate.shape:
        raise ValueError("images must have identical shapes")
    x = reference.astype(np.float64)
    y = candidate.astype(np.float64)
    c1 = (0.01 * 255) ** 2
    c2 = (0.03 * 255) ** 2
    values = []
    for channel in range(3):
        a = x[:, :, channel]
        b = y[:, :, channel]
        mu_a = cv2.GaussianBlur(a, (11, 11), 1.5)
        mu_b = cv2.GaussianBlur(b, (11, 11), 1.5)
        sigma_a = cv2.GaussianBlur(a * a, (11, 11), 1.5) - mu_a * mu_a
        sigma_b = cv2.GaussianBlur(b * b, (11, 11), 1.5) - mu_b * mu_b
        sigma_ab = cv2.GaussianBlur(a * b, (11, 11), 1.5) - mu_a * mu_b
        score = ((2 * mu_a * mu_b + c1) * (2 * sigma_ab + c2)) / (
            (mu_a * mu_a + mu_b * mu_b + c1) * (sigma_a + sigma_b + c2)
        )
        values.append(float(score.mean()))
    return float(np.mean(values))
