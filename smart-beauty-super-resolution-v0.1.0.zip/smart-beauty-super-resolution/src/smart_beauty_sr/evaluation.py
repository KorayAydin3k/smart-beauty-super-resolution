from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from PIL import Image

from smart_beauty_sr.backends.base import SuperResolutionBackend
from smart_beauty_sr.backends.bicubic import BicubicBackend
from smart_beauty_sr.metrics import psnr, ssim


@dataclass(frozen=True, slots=True)
class EvaluationResult:
    bicubic_psnr: float
    bicubic_ssim: float
    model_psnr: float
    model_ssim: float


def _downsample(image: np.ndarray, scale: int) -> np.ndarray:
    height, width = image.shape[:2]
    target = (max(1, width // scale), max(1, height // scale))
    output = Image.fromarray(image, mode="RGB").resize(target, Image.Resampling.BICUBIC)
    return np.ascontiguousarray(np.asarray(output, dtype=np.uint8))


def evaluate_against_reference(
    reference: np.ndarray,
    backend: SuperResolutionBackend,
) -> EvaluationResult:
    scale = backend.scale
    usable_height = reference.shape[0] - reference.shape[0] % scale
    usable_width = reference.shape[1] - reference.shape[1] % scale
    reference = reference[:usable_height, :usable_width]
    low_resolution = _downsample(reference, scale)
    bicubic = BicubicBackend(scale).enhance(low_resolution)
    model = backend.enhance(low_resolution)
    return EvaluationResult(
        bicubic_psnr=psnr(reference, bicubic),
        bicubic_ssim=ssim(reference, bicubic),
        model_psnr=psnr(reference, model),
        model_ssim=ssim(reference, model),
    )
