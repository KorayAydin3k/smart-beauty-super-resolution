from __future__ import annotations

import time
from pathlib import Path

from smart_beauty_sr.backends.base import SuperResolutionBackend
from smart_beauty_sr.contracts import (
    Decision,
    ProcessRecord,
    ProcessingStatus,
    SRProfile,
    SmartBeautySRError,
)
from smart_beauty_sr.eligibility import evaluate_eligibility
from smart_beauty_sr.fingerprint import profile_sha256
from smart_beauty_sr.image_io import (
    atomic_write_png,
    decode_rgb,
    sha256_file,
    sha256_pixels,
)


def process_image(
    source_path: Path,
    output_path: Path,
    profile: SRProfile,
    backend: SuperResolutionBackend,
    *,
    overwrite: bool = False,
) -> ProcessRecord:
    started = time.perf_counter()
    fingerprint = profile_sha256(profile)
    source_hash: str | None = None
    source_pixel_hash: str | None = None

    if output_path.exists() and not overwrite:
        return ProcessRecord(
            source_path=str(source_path),
            output_path=str(output_path),
            status=ProcessingStatus.SKIPPED,
            decision=None,
            reason="output already exists",
            source_sha256=sha256_file(source_path),
            source_pixel_sha256=None,
            output_sha256=sha256_file(output_path),
            output_pixel_sha256=None,
            profile_sha256=fingerprint,
            source_width=None,
            source_height=None,
            output_width=None,
            output_height=None,
            focus_score=None,
            backend=backend.name,
            model_id=profile.model.model_id,
            model_revision=profile.model.revision,
            device=backend.device,
            elapsed_ms=(time.perf_counter() - started) * 1000,
        )

    try:
        source_hash = sha256_file(source_path)
        image = decode_rgb(source_path)
        source_pixel_hash = sha256_pixels(image)
        eligibility = evaluate_eligibility(image, profile)
        if eligibility.decision is Decision.REJECT:
            return ProcessRecord(
                source_path=str(source_path),
                output_path=None,
                status=ProcessingStatus.FAILED,
                decision=eligibility.decision,
                reason=eligibility.reason,
                source_sha256=source_hash,
                source_pixel_sha256=source_pixel_hash,
                output_sha256=None,
                output_pixel_sha256=None,
                profile_sha256=fingerprint,
                source_width=eligibility.metrics.width,
                source_height=eligibility.metrics.height,
                output_width=None,
                output_height=None,
                focus_score=eligibility.metrics.focus_score,
                backend=backend.name,
                model_id=profile.model.model_id,
                model_revision=profile.model.revision,
                device=backend.device,
                elapsed_ms=(time.perf_counter() - started) * 1000,
                error_type="ImageEligibilityRejected",
                error_message=eligibility.reason,
            )

        output = image if eligibility.decision is Decision.PASSTHROUGH else backend.enhance(image)
        expected_scale = 1 if eligibility.decision is Decision.PASSTHROUGH else profile.model.scale
        expected_width = image.shape[1] * expected_scale
        expected_height = image.shape[0] * expected_scale
        if output.shape != (expected_height, expected_width, 3):
            raise ValueError(
                f"backend output shape {output.shape} does not match "
                f"expected {(expected_height, expected_width, 3)}"
            )
        atomic_write_png(output_path, output)
        output_hash = sha256_file(output_path)
        return ProcessRecord(
            source_path=str(source_path),
            output_path=str(output_path),
            status=ProcessingStatus.SUCCESS,
            decision=eligibility.decision,
            reason=eligibility.reason,
            source_sha256=source_hash,
            source_pixel_sha256=source_pixel_hash,
            output_sha256=output_hash,
            output_pixel_sha256=sha256_pixels(output),
            profile_sha256=fingerprint,
            source_width=image.shape[1],
            source_height=image.shape[0],
            output_width=output.shape[1],
            output_height=output.shape[0],
            focus_score=eligibility.metrics.focus_score,
            backend=backend.name,
            model_id=profile.model.model_id,
            model_revision=profile.model.revision,
            device=backend.device,
            elapsed_ms=(time.perf_counter() - started) * 1000,
        )
    except (SmartBeautySRError, OSError, ValueError) as exc:
        return ProcessRecord(
            source_path=str(source_path),
            output_path=None,
            status=ProcessingStatus.FAILED,
            decision=None,
            reason=None,
            source_sha256=source_hash,
            source_pixel_sha256=source_pixel_hash,
            output_sha256=None,
            output_pixel_sha256=None,
            profile_sha256=fingerprint,
            source_width=None,
            source_height=None,
            output_width=None,
            output_height=None,
            focus_score=None,
            backend=backend.name,
            model_id=profile.model.model_id,
            model_revision=profile.model.revision,
            device=backend.device,
            elapsed_ms=(time.perf_counter() - started) * 1000,
            error_type=type(exc).__name__,
            error_message=str(exc),
        )
