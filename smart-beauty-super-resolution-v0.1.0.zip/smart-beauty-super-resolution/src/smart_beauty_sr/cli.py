from __future__ import annotations

import json
from pathlib import Path

import typer
from rich.console import Console

from smart_beauty_sr.batch import process_batch
from smart_beauty_sr.config import load_profile
from smart_beauty_sr.eligibility import evaluate_eligibility
from smart_beauty_sr.image_io import decode_rgb
from smart_beauty_sr.pipeline import process_image
from smart_beauty_sr.registry import create_backend

app = typer.Typer(no_args_is_help=True, add_completion=False)
console = Console()


@app.command()
def inspect(image: Path, profile: Path) -> None:
    """Inspect whether an image is eligible for analysis-safe SR."""
    loaded = load_profile(profile)
    result = evaluate_eligibility(decode_rgb(image), loaded)
    console.print_json(
        json.dumps(
            {
                "decision": result.decision.value,
                "reason": result.reason,
                "metrics": {
                    "width": result.metrics.width,
                    "height": result.metrics.height,
                    "pixels": result.metrics.pixels,
                    "short_side": result.metrics.short_side,
                    "focus_score": result.metrics.focus_score,
                },
            }
        )
    )


@app.command()
def enhance(
    image: Path,
    output: Path,
    profile: Path,
    overwrite: bool = typer.Option(False, "--overwrite"),
) -> None:
    """Enhance one image and write a manifest-like result to stdout."""
    loaded = load_profile(profile)
    backend = create_backend(loaded.model)
    record = process_image(image, output, loaded, backend, overwrite=overwrite)
    console.print_json(json.dumps(record.to_dict()))
    if record.status.value == "failed":
        raise typer.Exit(code=2)


@app.command("batch")
def batch_command(
    input_dir: Path,
    output_dir: Path,
    profile: Path,
    fail_fast: bool = typer.Option(False, "--fail-fast"),
    overwrite: bool = typer.Option(False, "--overwrite"),
) -> None:
    """Run deterministic batch enhancement."""
    loaded = load_profile(profile)
    backend = create_backend(loaded.model)
    result = process_batch(
        input_dir,
        output_dir,
        loaded,
        backend,
        fail_fast=fail_fast,
        overwrite=overwrite,
    )
    console.print(
        f"processed={len(result.records)} succeeded={result.succeeded} "
        f"failed={result.failed} skipped={result.skipped}"
    )
    console.print(f"manifest={result.manifest_path}")
    if result.failed:
        raise typer.Exit(code=2)
