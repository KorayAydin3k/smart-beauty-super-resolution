# Contributing

Before submitting a change:

```bash
uv sync --all-groups
uv run ruff check .
uv run mypy src
uv run pytest
uv run python -m build
```

Changes to model ID, revision, eligibility thresholds, color handling, output encoding, or determinism settings require an explicit evaluation note and private skin-image acceptance evidence.
