from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from PIL import Image

from smart_beauty_sr.config import load_profile
from smart_beauty_sr.pipeline import process_image
from smart_beauty_sr.registry import create_backend


def _synthetic_fixture(path: Path) -> Path:
    height, width = 96, 128
    y, x = np.mgrid[:height, :width]
    checker = ((x // 8 + y // 8) % 2) * 70
    image = np.stack(
        [
            np.clip(90 + checker + x, 0, 255),
            np.clip(70 + checker + y, 0, 255),
            np.clip(120 + checker, 0, 255),
        ],
        axis=-1,
    ).astype(np.uint8)
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(image).save(path)
    return path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("image", type=Path, nargs="?")
    parser.add_argument(
        "--profile",
        type=Path,
        default=Path("configs/analysis-safe-swin2sr-x2.yaml"),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("artifacts/model-smoke-output.png"),
    )
    args = parser.parse_args()

    image = args.image or _synthetic_fixture(Path("artifacts/model-smoke-input.png"))
    profile = load_profile(args.profile)
    backend = create_backend(profile.model)
    record = process_image(image, args.output, profile, backend, overwrite=True)
    print(json.dumps(record.to_dict(), indent=2, sort_keys=True))
    if record.status.value != "success":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
