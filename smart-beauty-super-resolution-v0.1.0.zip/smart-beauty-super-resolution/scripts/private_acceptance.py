from __future__ import annotations

import argparse
import json
from pathlib import Path

from smart_beauty_sr.batch import process_batch
from smart_beauty_sr.config import load_profile
from smart_beauty_sr.registry import create_backend


def _hashes(manifest: Path) -> dict[str, str | None]:
    records = [json.loads(line) for line in manifest.read_text(encoding="utf-8").splitlines()]
    return {Path(record["source_path"]).name: record["output_sha256"] for record in records}


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run a private two-pass determinism acceptance check without committing images."
    )
    parser.add_argument("input_dir", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument(
        "--profile",
        type=Path,
        default=Path("configs/analysis-safe-swin2sr-x2.yaml"),
    )
    args = parser.parse_args()

    profile = load_profile(args.profile)
    first_backend = create_backend(profile.model)
    first = process_batch(
        args.input_dir,
        args.output_dir / "run_1",
        profile,
        first_backend,
        overwrite=True,
    )
    second_backend = create_backend(profile.model)
    second = process_batch(
        args.input_dir,
        args.output_dir / "run_2",
        profile,
        second_backend,
        overwrite=True,
    )
    first_hashes = _hashes(first.manifest_path)
    second_hashes = _hashes(second.manifest_path)
    report = {
        "profile_id": profile.profile_id,
        "backend": profile.model.backend,
        "model_id": profile.model.model_id,
        "model_revision": profile.model.revision,
        "run_1": {"succeeded": first.succeeded, "failed": first.failed},
        "run_2": {"succeeded": second.succeeded, "failed": second.failed},
        "same_runtime_output_hashes_match": first_hashes == second_hashes,
        "output_hashes": first_hashes,
    }
    report_path = args.output_dir / "acceptance_report.json"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))
    if first.failed or second.failed or first_hashes != second_hashes:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
