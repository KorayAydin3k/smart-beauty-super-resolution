from __future__ import annotations

import argparse
import json
from pathlib import Path

from smart_beauty_sr.config import load_profile
from smart_beauty_sr.evaluation import evaluate_against_reference
from smart_beauty_sr.image_io import decode_rgb
from smart_beauty_sr.registry import create_backend


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Evaluate SR against a high-resolution reference using synthetic downsampling."
    )
    parser.add_argument("reference", type=Path)
    parser.add_argument(
        "--profile",
        type=Path,
        default=Path("configs/analysis-safe-swin2sr-x2.yaml"),
    )
    args = parser.parse_args()

    profile = load_profile(args.profile)
    backend = create_backend(profile.model)
    result = evaluate_against_reference(decode_rgb(args.reference), backend)
    print(
        json.dumps(
            {
                "backend": backend.name,
                "device": backend.device,
                "bicubic_psnr": result.bicubic_psnr,
                "bicubic_ssim": result.bicubic_ssim,
                "model_psnr": result.model_psnr,
                "model_ssim": result.model_ssim,
                "psnr_delta": result.model_psnr - result.bicubic_psnr,
                "ssim_delta": result.model_ssim - result.bicubic_ssim,
            },
            indent=2,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
