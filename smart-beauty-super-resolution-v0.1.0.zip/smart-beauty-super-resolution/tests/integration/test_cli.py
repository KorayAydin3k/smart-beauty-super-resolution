from pathlib import Path

import pytest
from typer.testing import CliRunner

from smart_beauty_sr.cli import app

pytestmark = pytest.mark.integration
runner = CliRunner()


def test_inspect_command(image_path: Path) -> None:
    result = runner.invoke(
        app,
        ["inspect", str(image_path), "configs/bicubic-baseline-x2.yaml"],
    )
    assert result.exit_code == 0
    assert '"decision": "enhance"' in result.stdout
