from pathlib import Path

import pytest
from PIL import Image

from smart_beauty_sr.backends.bicubic import BicubicBackend
from smart_beauty_sr.batch import process_batch
from smart_beauty_sr.contracts import OutputCollisionError

pytestmark = pytest.mark.integration


def test_batch_writes_manifest_and_summary(image_path, tmp_path: Path, baseline_profile) -> None:
    input_dir = tmp_path / "inputs"
    input_dir.mkdir()
    target = input_dir / "skin.jpg"
    target.write_bytes(image_path.read_bytes())
    result = process_batch(input_dir, tmp_path / "outputs", baseline_profile, BicubicBackend(2))
    assert result.succeeded == 1
    assert result.failed == 0
    assert result.manifest_path.exists()
    assert result.summary_path.exists()


def test_collision_preflight_rejects_duplicate_stems(
    image_path, tmp_path: Path, baseline_profile
) -> None:
    input_dir = tmp_path / "inputs"
    input_dir.mkdir()
    for name in ("sample.jpg", "sample.png"):
        Image.open(image_path).save(input_dir / name)
    with pytest.raises(OutputCollisionError):
        process_batch(input_dir, tmp_path / "outputs", baseline_profile, BicubicBackend(2))


def test_second_batch_run_is_skipped(image_path, tmp_path: Path, baseline_profile) -> None:
    input_dir = tmp_path / "inputs"
    input_dir.mkdir()
    (input_dir / "skin.jpg").write_bytes(image_path.read_bytes())
    output_dir = tmp_path / "outputs"
    first = process_batch(input_dir, output_dir, baseline_profile, BicubicBackend(2))
    second = process_batch(input_dir, output_dir, baseline_profile, BicubicBackend(2))
    assert first.succeeded == 1
    assert second.skipped == 1
    assert second.succeeded == 0
