import math

from smart_beauty_sr.metrics import psnr, ssim


def test_identical_images_have_perfect_metrics(sharp_image) -> None:
    assert math.isinf(psnr(sharp_image, sharp_image))
    assert ssim(sharp_image, sharp_image) == 1.0
