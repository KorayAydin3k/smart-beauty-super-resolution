import numpy as np
import pytest

from smart_beauty_sr.backends.hf_swin2sr import reconstruction_to_rgb_uint8
from smart_beauty_sr.contracts import BackendInferenceError


def test_reconstruction_conversion_crops_processor_padding() -> None:
    array = np.zeros((3, 12, 16), dtype=np.float32)
    array[0] = 1.0
    output = reconstruction_to_rgb_uint8(array, expected_height=10, expected_width=14)
    assert output.shape == (10, 14, 3)
    assert np.all(output[:, :, 0] == 255)
    assert np.all(output[:, :, 1:] == 0)


def test_reconstruction_conversion_rejects_small_output() -> None:
    array = np.zeros((3, 4, 4), dtype=np.float32)
    with pytest.raises(BackendInferenceError, match="smaller"):
        reconstruction_to_rgb_uint8(array, expected_height=8, expected_width=8)
