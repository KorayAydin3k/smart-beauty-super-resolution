from pathlib import Path

from smart_beauty_sr.backends.bicubic import BicubicBackend
from smart_beauty_sr.contracts import Decision, ProcessingStatus
from smart_beauty_sr.pipeline import process_image


def test_pipeline_writes_expected_output(image_path, tmp_path: Path, baseline_profile) -> None:
    output = tmp_path / "out.png"
    record = process_image(image_path, output, baseline_profile, BicubicBackend(2))
    assert record.status is ProcessingStatus.SUCCESS
    assert record.decision is Decision.ENHANCE
    assert (record.output_width, record.output_height) == (128, 96)
    assert output.exists()


def test_pipeline_is_deterministic(image_path, tmp_path: Path, baseline_profile) -> None:
    first = process_image(image_path, tmp_path / "one.png", baseline_profile, BicubicBackend(2))
    second = process_image(image_path, tmp_path / "two.png", baseline_profile, BicubicBackend(2))
    assert first.output_sha256 == second.output_sha256


class _BrokenShapeBackend:
    name = "broken-shape"
    scale = 2
    device = "cpu"

    def enhance(self, image):
        return image


class _ProgrammingErrorBackend:
    name = "programming-error"
    scale = 2
    device = "cpu"

    def enhance(self, image):
        raise RuntimeError("unexpected programming defect")


def test_pipeline_rejects_invalid_backend_shape(
    image_path, tmp_path: Path, baseline_profile
) -> None:
    record = process_image(
        image_path,
        tmp_path / "bad.png",
        baseline_profile,
        _BrokenShapeBackend(),
    )
    assert record.status is ProcessingStatus.FAILED
    assert record.error_type == "ValueError"


def test_unexpected_runtime_error_is_not_swallowed(
    image_path, tmp_path: Path, baseline_profile
) -> None:
    import pytest

    with pytest.raises(RuntimeError, match="programming defect"):
        process_image(
            image_path,
            tmp_path / "bad.png",
            baseline_profile,
            _ProgrammingErrorBackend(),
        )


def test_existing_output_is_skipped_without_overwrite(
    image_path, tmp_path: Path, baseline_profile
) -> None:
    output = tmp_path / "out.png"
    first = process_image(image_path, output, baseline_profile, BicubicBackend(2))
    second = process_image(image_path, output, baseline_profile, BicubicBackend(2))
    assert first.status is ProcessingStatus.SUCCESS
    assert second.status is ProcessingStatus.SKIPPED
    assert second.output_sha256 == first.output_sha256
