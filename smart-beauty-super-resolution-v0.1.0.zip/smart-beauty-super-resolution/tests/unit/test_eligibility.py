import numpy as np

from smart_beauty_sr.contracts import Decision
from smart_beauty_sr.eligibility import evaluate_eligibility


def test_sharp_low_resolution_image_is_enhanced(sharp_image, baseline_profile) -> None:
    result = evaluate_eligibility(sharp_image, baseline_profile)
    assert result.decision is Decision.ENHANCE


def test_blurred_image_is_rejected(baseline_profile) -> None:
    image = np.full((64, 64, 3), 127, dtype=np.uint8)
    result = evaluate_eligibility(image, baseline_profile)
    assert result.decision is Decision.REJECT
    assert "blurred" in result.reason


def test_large_short_side_is_passthrough(sharp_image, baseline_profile) -> None:
    image = np.tile(sharp_image, (24, 24, 1))
    result = evaluate_eligibility(image, baseline_profile)
    assert result.decision is Decision.PASSTHROUGH
