from pathlib import Path

import numpy as np
import pytest

from smart_beauty_sr.image_io import atomic_write_png


def test_atomic_writer_cleans_temp_file_on_replace_failure(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    image = np.zeros((16, 16, 3), dtype=np.uint8)
    output = tmp_path / "output.png"

    def fail_replace(source, destination):
        raise OSError("replace failed")

    monkeypatch.setattr("smart_beauty_sr.image_io.os.replace", fail_replace)
    with pytest.raises(OSError, match="replace failed"):
        atomic_write_png(output, image)

    assert not output.exists()
    assert list(tmp_path.iterdir()) == []
