from pathlib import Path

import pytest

from smart_beauty_sr.config import load_profile, profile_from_mapping
from smart_beauty_sr.contracts import ConfigurationError


def test_loads_baseline_profile() -> None:
    profile = load_profile(Path("configs/bicubic-baseline-x2.yaml"))
    assert profile.model.backend == "bicubic"
    assert profile.model.scale == 2


def test_rejects_unknown_fields() -> None:
    payload = {
        "schema_version": "1.0",
        "profile_id": "test",
        "profile_version": "0.1.0",
        "model": {
            "backend": "bicubic",
            "scale": 2,
            "model_id": None,
            "revision": None,
            "device": "cpu",
            "deterministic": True,
            "use_safetensors": True,
        },
        "eligibility": {
            "enhance_if_short_side_below": 1024,
            "min_focus_score": 0.0,
            "passthrough_if_not_needed": True,
        },
        "source_limits": {
            "max_width": 4096,
            "max_height": 4096,
            "max_pixels": 16777216,
            "max_output_pixels": 67108864,
        },
        "output_format": "png",
        "unexpected": True,
    }
    with pytest.raises(ConfigurationError, match="unknown fields"):
        profile_from_mapping(payload)


def test_hf_profile_requires_full_revision() -> None:
    from smart_beauty_sr.contracts import ModelConfig

    with pytest.raises(ConfigurationError, match="40-character"):
        ModelConfig(
            backend="hf_swin2sr",
            scale=2,
            model_id="caidas/swin2SR-classical-sr-x2-64",
            revision="cee1c92",
        )
