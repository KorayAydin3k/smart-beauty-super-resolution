from smart_beauty_sr.fingerprint import profile_sha256


def test_profile_fingerprint_is_stable(baseline_profile) -> None:
    first = profile_sha256(baseline_profile)
    second = profile_sha256(baseline_profile)
    assert len(first) == 64
    assert first == second
