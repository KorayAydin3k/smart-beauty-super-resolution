from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest
from PIL import Image

from smart_beauty_sr.config import load_profile
from smart_beauty_sr.contracts import SRProfile


@pytest.fixture
def sharp_image() -> np.ndarray:
    image = np.zeros((48, 64, 3), dtype=np.uint8)
    image[:, :32] = (20, 80, 140)
    image[:, 32:] = (220, 180, 80)
    image[12:36, 20:44] = (240, 40, 50)
    return image


@pytest.fixture
def image_path(tmp_path: Path, sharp_image: np.ndarray) -> Path:
    path = tmp_path / "input.jpg"
    Image.fromarray(sharp_image).save(path, quality=95)
    return path


@pytest.fixture
def baseline_profile() -> SRProfile:
    return load_profile(Path("configs/bicubic-baseline-x2.yaml"))
