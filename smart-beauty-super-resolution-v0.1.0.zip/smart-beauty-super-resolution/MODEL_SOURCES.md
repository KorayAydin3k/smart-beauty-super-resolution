# Model sources and licensing

## Primary analysis-safe baseline

- Model: `caidas/swin2SR-classical-sr-x2-64`
- Provider: CAIDAS / Hugging Face
- Architecture: Swin2SR
- Scale: x2
- License: Apache-2.0
- Pinned revision: `cee1c923c6a37361c6e5650b65dcf4be821e5d52`
- Weights are downloaded at runtime and are not stored in this repository.

## Reference implementations reviewed

- Swin2SR official implementation: https://github.com/mv-lab/swin2sr
- SwinIR official implementation: https://github.com/JingyunLiang/SwinIR
- Real-ESRGAN official implementation: https://github.com/xinntao/Real-ESRGAN

Real-ESRGAN is not used in the analysis-safe default because perceptual/GAN restoration may introduce plausible-looking details that are not reliable evidence for skin analysis.
