from __future__ import annotations

import argparse
import json
import statistics
import time
from pathlib import Path

from smart_beauty_sr.config import load_profile
from smart_beauty_sr.image_io import decode_rgb
from smart_beauty_sr.registry import create_backend


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("image", type=Path)
    parser.add_argument(
        "--profile",
        type=Path,
        default=Path("configs/analysis-safe-swin2sr-x2.yaml"),
    )
    parser.add_argument("--iterations", type=int, default=3)
    args = parser.parse_args()

    profile = load_profile(args.profile)
    backend = create_backend(profile.model)
    image = decode_rgb(args.image)
    backend.enhance(image)  # warm-up and model download/load
    durations = []
    for _ in range(args.iterations):
        started = time.perf_counter()
        backend.enhance(image)
        durations.append((time.perf_counter() - started) * 1000)
    print(json.dumps({
        "backend": backend.name,
        "device": backend.device,
        "iterations": args.iterations,
        "median_ms": statistics.median(durations),
        "min_ms": min(durations),
        "max_ms": max(durations),
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
