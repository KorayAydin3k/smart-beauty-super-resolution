# Architecture decision: keep SR separate from resize

## Decision

Super-resolution is implemented as a separate package and repository, then composed with the deterministic resize preprocessor at pipeline level.

## Reasons

- SR depends on learned weights and optional GPU runtimes.
- Model upgrades require model-specific evaluation and licensing review.
- Deterministic resize must remain lightweight and stable.
- SR may be skipped or rejected by eligibility policy without changing resize behavior.
- Analysis-safe and preview-only enhancement must remain separable.

## Consequence

The handoff contract is an RGB image plus provenance. The existing resize preprocessor remains the canonical geometry stage after optional SR.
