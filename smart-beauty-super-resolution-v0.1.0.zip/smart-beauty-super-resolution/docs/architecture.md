# Architecture

The package is a separate component from the deterministic resize preprocessor.

```text
capture / dataset image
        ↓
quality and eligibility gate
        ├─ unsafe or too blurred → reject / retake
        ├─ already sufficient   → canonical passthrough
        └─ eligible low-res     → Swin2SR x2
                                  ↓
                          resize preprocessor v1.0.0
                                  ↓
                        face/skin ROI and model inference
```

The separation prevents neural dependencies, model weights, device behavior, and model licensing from changing the deterministic resize contract.
