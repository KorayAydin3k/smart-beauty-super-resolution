# Analysis-safety rules

1. Super-resolution is optional and eligibility-gated.
2. The analysis path uses a fidelity-oriented x2 model, not a GAN-based face enhancer.
3. Images below the focus threshold are rejected rather than "reconstructed".
4. Model ID, immutable revision, input hash, output hash, device, and timing are recorded.
5. A super-resolved image is not ground truth and must not be used as evidence that a lesion or texture existed in the source.
6. Perceptual preview models, if added later, must be isolated from acne, texture, redness, and firmness scoring.
7. Public test fixtures must not contain private or identifiable user images.
