# Evaluation plan

## Offline paired evaluation

Start from high-resolution reference images, create deterministic low-resolution inputs, and compare:

- bicubic x2 baseline;
- Swin2SR x2 output;
- PSNR and SSIM against the reference;
- inference latency and peak memory;
- output repeatability;
- downstream acne/texture score drift.

## Private skin-image acceptance

Private images are processed locally and are never committed. Acceptance requires:

- no geometry distortion;
- no crop;
- stable color statistics;
- no new lesion-like structures on manual review;
- identical output hash in repeated runs on the same runtime;
- bounded downstream score drift relative to the original image path.

The model must not be approved solely because the output looks sharper.
