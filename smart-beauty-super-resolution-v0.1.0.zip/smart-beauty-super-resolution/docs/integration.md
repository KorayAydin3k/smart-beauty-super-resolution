# Integration

Install the base package:

```bash
uv sync --all-groups
```

Install the neural backend:

```bash
uv sync --all-groups --extra model
```

Inspect eligibility:

```bash
uv run smart-beauty-sr inspect image.jpg configs/analysis-safe-swin2sr-x2.yaml
```

Enhance one image:

```bash
uv run smart-beauty-sr enhance image.jpg output.png configs/analysis-safe-swin2sr-x2.yaml
```

Batch processing:

```bash
uv run smart-beauty-sr batch data/raw data/sr configs/analysis-safe-swin2sr-x2.yaml
```
