# Smart Beauty Super-Resolution

Analysis-safe, auditable super-resolution for Smart Beauty image pipelines.

This repository is intentionally separate from `smart-beauty-resize-preprocessor`. Resize is a deterministic geometry contract; super-resolution is a learned restoration model with model weights, device-specific execution, and a different validation burden.

## Default design

- fidelity-first Swin2SR x2 backend;
- deterministic bicubic baseline;
- eligibility gate before neural inference;
- reject images that are too blurred or exceed safety limits;
- canonical RGB PNG outputs;
- atomic publication;
- source/output SHA-256 provenance;
- deterministic batch discovery and collision preflight;
- JSONL manifest and run summary;
- no model weights or private skin images committed.

## Pipeline position

```text
capture → quality gate → optional super-resolution → resize preprocessor → skin ROI → model
```

## Quick start

```bash
uv sync --all-groups
uv run pytest
uv run smart-beauty-sr inspect image.jpg configs/bicubic-baseline-x2.yaml
```

For the neural backend:

```bash
uv sync --all-groups --extra model
uv run smart-beauty-sr enhance input.jpg output.png configs/analysis-safe-swin2sr-x2.yaml
```

## Why x2 and fidelity-first

The analysis path should recover resolution conservatively rather than maximize perceived sharpness. GAN-based face enhancement is excluded from the default because it may create plausible texture that was not present in the source.

## Release status

`0.1.0` is the baseline architecture and validation release. Model approval still requires private skin-image evaluation and downstream score-drift analysis on the target deployment hardware.

See `docs/` and `MODEL_SOURCES.md` for architecture, safety, evaluation, and licensing details.
