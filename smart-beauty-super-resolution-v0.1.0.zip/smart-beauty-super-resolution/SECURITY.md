# Security and data handling

- Do not commit private skin images, model-service credentials, or Hugging Face tokens.
- Model weights are downloaded from the pinned public model revision at runtime.
- Keep private acceptance inputs outside the repository.
- Review dependency and model-source changes before deployment.
- Treat super-resolved outputs as derived data and apply the same access controls as the source images.
