# Changelog

## 0.1.0 — Baseline architecture

- Separate super-resolution package and CLI.
- Fidelity-first Hugging Face Swin2SR x2 backend.
- Deterministic bicubic baseline.
- Resolution, focus, source-size, and projected-output safety gates.
- Atomic RGB PNG output and SHA-256 provenance.
- Deterministic batch discovery, collision preflight, manifest, and summary.
- PSNR/SSIM evaluation helpers.
- Unit, integration, CLI, and determinism tests.
- Automated quality workflow and manual pretrained-model smoke workflow.
